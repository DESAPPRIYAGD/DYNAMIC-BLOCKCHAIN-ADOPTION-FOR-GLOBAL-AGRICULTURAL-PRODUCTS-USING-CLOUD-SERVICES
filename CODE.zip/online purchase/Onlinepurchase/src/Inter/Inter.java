package Inter;

import Bean.cartbean;
import Bean.addvegbean;
import Bean.customerregbean;
import Bean.dcartbean;
import Bean.sellerregbean;

public interface Inter {

	public int cusreg(customerregbean tb);
	public boolean cuslog(customerregbean tb);
	public int selreg(sellerregbean tb);
	public boolean sellog(sellerregbean tb);
	public int vegadd(addvegbean tb);
	public int car(cartbean cb);
	public int dcar(dcartbean db);
}
