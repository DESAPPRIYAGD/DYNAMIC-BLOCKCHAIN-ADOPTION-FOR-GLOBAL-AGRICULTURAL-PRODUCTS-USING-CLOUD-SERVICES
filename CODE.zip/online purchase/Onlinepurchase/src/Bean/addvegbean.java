package Bean;

public class addvegbean {
private String time,name,mail,vid,vname,tquan,price,state,image,date,address;

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getTime() {
	return time;
}

public void setTime(String time) {
	this.time = time;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getMail() {
	return mail;
}

public void setMail(String mail) {
	this.mail = mail;
}

public String getVid() {
	return vid;
}

public void setVid(String vid) {
	this.vid = vid;
}

public String getVname() {
	return vname;
}

public void setVname(String vname) {
	this.vname = vname;
}

public String getTquan() {
	return tquan;
}

public void setTquan(String tquan) {
	this.tquan = tquan;
}

public String getPrice() {
	return price;
}

public void setPrice(String price) {
	this.price = price;
}

public String getState() {
	return state;
}

public void setState(String state) {
	this.state = state;
}

public String getImage() {
	return image;
}

public void setImage(String image) {
	this.image = image;
}
}
