package Bean;

public class sellerregbean {
private String name,email,mobile,address,bname,baccount,bifsc,pass,cpass,idproof,location,status;

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getBname() {
	return bname;
}

public void setBname(String bname) {
	this.bname = bname;
}

public String getBaccount() {
	return baccount;
}

public void setBaccount(String baccount) {
	this.baccount = baccount;
}

public String getBifsc() {
	return bifsc;
}

public void setBifsc(String bifsc) {
	this.bifsc = bifsc;
}

public String getPass() {
	return pass;
}

public void setPass(String pass) {
	this.pass = pass;
}

public String getCpass() {
	return cpass;
}

public void setCpass(String cpass) {
	this.cpass = cpass;
}

public String getIdproof() {
	return idproof;
}

public void setIdproof(String idproof) {
	this.idproof = idproof;
}
}
