package Imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Bean.cartbean;



import Bean.Block;
import Bean.addvegbean;
import Bean.customerregbean;
import Bean.dcartbean;
import Bean.sellerregbean;


import Dbcon.dbcon;

import Inter.Inter;

public class Imple implements Inter {

	Connection con;
	@Override
	public int cusreg(customerregbean tb) {
		// TODO Auto-generated method stub
		
		int reg=0;
		
		con=dbcon.create();
		
		try {
 			
				PreparedStatement ps=con.prepareStatement("INSERT INTO onpur.cusreg VALUES(id,?,?,?,?,?,?)");
				ps.setString(1, tb.getName());
				ps.setString(2, tb.getEmail());
				ps.setString(3, tb.getMobile());
				ps.setString(4, tb.getPass());
				ps.setString(5, tb.getCpass());
				ps.setString(6, tb.getImage());
				
				
				reg=ps.executeUpdate();

} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
		
return reg;
	}
	@Override
	public boolean cuslog(customerregbean tb) {
		// TODO Auto-generated method stub
		boolean log=false;
		 
		con=dbcon.create();
		
		 try {
				PreparedStatement ps=con.prepareStatement("SELECT * FROM `onpur`.`cusreg` where  email=? and pass=?");
				
				ps.setString(1, tb.getEmail());
				ps.setString(2, tb.getPass());
				
				ResultSet rs=ps.executeQuery();
				log=rs.next();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return log;

	}
	@Override
	public int selreg(sellerregbean tb) {
		// TODO Auto-generated method stub
		
		int reg=0;
		
		con=dbcon.create();
		
		try {
 			
				PreparedStatement ps=con.prepareStatement("INSERT INTO onpur.selreg VALUES(?,?,?,?,?,?,?,?,?)");
				ps.setString(1,  tb.getName());
				ps.setString(2,  tb.getEmail());
				ps.setString(3,  tb.getMobile());
				ps.setString(4,  tb.getAddress());
				
				ps.setString(5,  tb.getPass());
				ps.setString(6,  tb.getCpass());
				ps.setString(7, tb.getIdproof());
				ps.setString(8, tb.getLocation());
				ps.setString(9, "Not Activate");
				
				
				reg=ps.executeUpdate();

} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
		
return reg;
	}
	@Override
	public boolean sellog(sellerregbean tb) {
		// TODO Auto-generated method stub
		boolean log=false;
		 
		con=dbcon.create();
		
		 try {
				PreparedStatement ps=con.prepareStatement("SELECT * FROM `onpur`.`selreg` where  email=? and location=? and status=?");
				
				ps.setString(1, tb.getEmail());
				ps.setString(2, tb.getLocation());
				ps.setString(3, tb.getStatus());
				
				ResultSet rs=ps.executeQuery();
				log=rs.next();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return log;

	}
	public int vegadd(addvegbean tb) {
		// TODO Auto-generated method stub
		
		int reg=0;
		
		con=dbcon.create();
		
		try {
 			
				PreparedStatement ps=con.prepareStatement("INSERT INTO onpur.addveg VALUES(id,?,?,?,?,?,?,?,?,?,?,?,?)");
				ps.setString(1, tb.getDate());
				ps.setString(2, tb.getName());
				ps.setString(3, tb.getMail());
				ps.setString(4, tb.getVid());
				ps.setString(5, tb.getVname());
				ps.setString(6, tb.getTquan());
				ps.setString(7, tb.getPrice());
				ps.setString(8, tb.getState());
				ps.setString(9, tb.getImage());
				ps.setString(10, tb.getTime());
				ps.setString(11,"not approved");
				ps.setString(12, tb.getAddress());
				
				reg=ps.executeUpdate();
				
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
		
return reg;
	}
	@Override
	public int car(cartbean cb) {
		int u=0;
		try
		{
		con=dbcon.create();
		PreparedStatement ps = con.prepareStatement("INSERT INTO onpur.cart VALUES(cartid,?,?,1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, cb.getProductid());
		ps.setString(2, cb.getSemail());
	    ps.setString(3, cb.getVid());
		ps.setString(4, cb.getPname());
		ps.setString(5, cb.getPrice());
		ps.setString(6, cb.getPic());
		ps.setString(7, cb.getCemail());
		ps.setString(8, "Add to cart");
		ps.setString(9, cb.getTotal());
		ps.setString(10,cb.getUuid());
		ps.setString(11, cb.getDtype());
		ps.setString(12, cb.getAdd());
		ps.setString(13, cb.getPaymenttype());
		
		
		String prehash="";
		String afterhash="";


		String ad="Technician";
		Connection con;
		con=dbcon.create();
		try {
			java.sql.PreparedStatement pa=con.prepareStatement("SELECT * FROM `onpur`.`cart` ");
					
			ResultSet rs=pa.executeQuery();
			while(rs.next()){
				prehash=rs.getString(16);
				afterhash=rs.getString(17);
				System.out.println("afterhash"+afterhash);
			}
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		prehash=afterhash;

		 
		 
		 
		Block genesisBlock = new Block("Hi im the first block", "0");

		String phas=genesisBlock.hash;

		Block secondBlock = new Block("Yo im the second block",genesisBlock.hash);
		System.out.println("Hash for block 2 : " + secondBlock.hash);
		String aphas=secondBlock.hash;
		System.out.println("prehash-"+prehash);
		
		
		ps.setString(14, prehash);
		ps.setString(15, aphas);
		
		ps.setString(16, "");
		ps.setString(17, "");
		ps.setString(18, "");
		ps.setString(19, "");
		ps.setString(20, "");
		u=ps.executeUpdate();

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return u;
}
	@Override
	public int dcar(dcartbean db) {
		int u=0;
		try
		{
		con=dbcon.create();
		PreparedStatement ps = con.prepareStatement("INSERT INTO onpur.cart VALUES(cartid,?,?,1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, db.getProductid());
		ps.setString(2, db.getSemail());
	    ps.setString(3, db.getVid());
		ps.setString(4, db.getPname());
		ps.setString(5, db.getPrice());
		ps.setString(6, db.getPic());
		ps.setString(7, db.getCemail());
		ps.setString(8, "Add to cart");
		ps.setString(9, db.getTotal());
		ps.setString(10,db.getUuid());
		ps.setString(11, db.getDtype());
		ps.setString(12, db.getAdd());
		ps.setString(13, db.getPtype());


		String prehash="";
		String afterhash="";


		String ad="Technician";
		Connection con;
		con=dbcon.create();
		try {
			java.sql.PreparedStatement pa=con.prepareStatement("SELECT * FROM `onpur`.`cart` ");
					
			ResultSet rs=pa.executeQuery();
			while(rs.next()){
				prehash=rs.getString(16);
				afterhash=rs.getString(17);
				System.out.println("afterhash"+afterhash);
			}
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		prehash=afterhash;

		 
		 
		 
		Block genesisBlock = new Block("Hi im the first block", "0");

		String phas=genesisBlock.hash;

		Block secondBlock = new Block("Yo im the second block",genesisBlock.hash);
		System.out.println("Hash for block 2 : " + secondBlock.hash);
		String aphas=secondBlock.hash;
		System.out.println("prehash-"+prehash);
		
		
		ps.setString(14, prehash);
		ps.setString(15, aphas);
		ps.setString(16, "");
		ps.setString(17, "");
		ps.setString(18, "");
		ps.setString(19, "");
		ps.setString(20, "");
	
		u=ps.executeUpdate();

		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return u;
}
}