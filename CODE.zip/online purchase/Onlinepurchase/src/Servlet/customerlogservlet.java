package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.customerregbean;

import Imple.Imple;
import Inter.Inter;


/**
 * Servlet implementation class TlLogServlet
 */
@WebServlet("/customerlogservlet")
public class customerlogservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public customerlogservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String location=request.getParameter("Location");
		System.out.println("userLocation: "+location);
		
		HttpSession sess=request.getSession();
		sess.setAttribute( "loccus",location);
		
		String name=request.getParameter("mail");
		System.out.println("username: "+name);
		
		HttpSession ses=request.getSession();
		ses.setAttribute( "cemail",name);
	
		
		String pass=request.getParameter("password");
		System.out.println("password: "+pass);
		
		
		customerregbean ur=new customerregbean();
		
		ur.setEmail(name);
		ur.setPass(pass);
		
		
		Inter in=new Imple();
		boolean log=in.cuslog(ur);
		
		if(log==true){
			response.sendRedirect("main.jsp");
		}
		else{
			response.sendRedirect("error1.jsp");
		}
		
		
		
	}

}
